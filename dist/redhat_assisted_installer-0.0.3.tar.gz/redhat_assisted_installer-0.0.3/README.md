# red-hat-assisted-installer
Python module to implement the RedHat Assisted Installer 


## Description


## Requirements